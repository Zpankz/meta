# Skill Refactor Index

Generated: 2026-02-15T07:24:47.038577Z
- Canonical skills: 37
- Total nodes: 37
- Demotion edges for DAG/trace compatibility: 75
- Transitive reduction edges reclassified as soft refs: 51
- Bridge candidates: 6
- Atomic node ratio: 0.4865
- Max DAG depth: 8
- MCTSR score: 100.0000
- Validation status: resolved

